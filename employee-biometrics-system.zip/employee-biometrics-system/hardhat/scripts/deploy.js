async function main() {
    const [deployer] = await ethers.getSigners();
    const EmployeeBiometricSystem = await ethers.getContractFactory("EmployeeBiometricSystem");
    const contract = await EmployeeBiometricSystem.deploy();
    console.log("EmployeeBiometricSystem deployed to:", contract.target);
}

main()
    .then(() => process.exit(0))
    .catch((error) => {
        console.error(error);
        process.exit(1);
    });
