const { ethers } = require("ethers");
const contractAddress = "0x5FbDB2315678afecb367f032d93F642f64180aa3";
const contractABI = require('./EmployeeBiometricSystem.json').abi;

const provider = new ethers.providers.JsonRpcProvider("http://127.0.0.1:8545/");

const signer = new ethers.Wallet("0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80", provider);

const contract = new ethers.Contract(contractAddress, contractABI, signer);

export async function addOrganization(organizationAddress, organizationName) {
    await contract.addOrganization(organizationAddress, organizationName);
    console.log('added')
}

export async function addEmployee(organizationAddress, employeeAddress, name, department, payPerHour) {
    await contract.addEmployee(organizationAddress, employeeAddress, name, department, payPerHour);
}

async function clockIn(organizationAddress, employeeAddress) {
    await contract.clockIn(organizationAddress, employeeAddress);
}

async function clockOut(organizationAddress, employeeAddress) {
    await contract.clockOut(organizationAddress, employeeAddress);
}

export async function getAllClockRecordsOfAnEmployee(employeeId) {
debugger;
    let clockRecords = await contract.getAllClockRecordsOfAnEmployee(employeeId);
    clockRecords = clockRecords.map(record => ({
        id: record[0].toNumber(),
        employeeId: record[1].toNumber(),
        clockIn: new Date(record[2].toNumber() * 1000).toLocaleString('en-US', { hour: 'numeric', minute: 'numeric', second: 'numeric', hour12: true }),
        clockOut: new Date(record[3].toNumber() * 1000).toLocaleString('en-US', { hour: 'numeric', minute: 'numeric', second: 'numeric', hour12: true }),
        date: new Date(record[4].toNumber() * 1000).toLocaleString('en-US', { year: 'numeric', month: 'numeric', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', hour12: true }),
        duration: record[5].toNumber()
    }));
    console.log(clockRecords);
    return clockRecords;
}

// Get Employee
export async function getEmployee(employeeAddress) {
    let emp = await contract.getEmployee(employeeAddress);
    emp = emp.map((value) => (value._isBigNumber ? value.toNumber() : value));

    const employee = {
        id: emp[0],
        employeeAddress: emp[1],
        name: emp[2],
        department: emp[3],
        totalHoursWorked: emp[4],
        totalPaidHours: emp[5],
        totalUnpaidHours: emp[6],
        payPerHour: emp[7],
        lastClockInTime: emp[8],
        organizationId: emp[9]
    };

    console.log(employee);
    return employee;
}

export async function getAllEmployees() {
    const emps = await contract.getAllEmployees();
    console.log(emps);
    return emps;
}

export async function isEmployeeExist(employeeAddress) {
    const isExist = await contract.isEmployeeExist(employeeAddress);
    console.log(isExist);
    return isExist;
}

export async function isOrganizationExist(organizationAddress) {
    const isExist = await contract.isOrganizationExist(organizationAddress);
    console.log(isExist);
    return isExist;
}

async function getOrganizationByAddress(organizationAddress) {
    const org = await contract.getOrganizationByAddress(organizationAddress);
    console.log(org);
    return org;
}

export async function getEmployeesOfAnOrganization(organizationAddress) {
    const orgEmps = await contract.getEmployeesOfAnOrganization(organizationAddress);
    const formattedEmps = orgEmps.map(emp => ({

        id: emp[0],
        employeeAddress: emp[1],
        name: emp[2],
        department: emp[3],
        totalHoursWorked: emp[4].toNumber(),
        totalPaidHours: emp[5].toNumber(),
        totalUnpaidHours: emp[6].toNumber(),
        payPerHour: emp[7].toNumber(),
        lastClockInTime: emp[8].toNumber(),
        organizationId: emp[9].toNumber()
    }));
    console.log(formattedEmps);
    return formattedEmps;
}

async function isEmployeeExistInOrganization(organizationAddress) {
    const isExist = await contract.isEmployeeExistInOrganization(organizationAddress);
    console.log(isExist);
    return isExist;
}

