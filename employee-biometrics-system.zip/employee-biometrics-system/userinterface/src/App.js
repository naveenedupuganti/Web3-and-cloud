import './App.css';
import { Link } from 'react-router-dom';
import React from 'react';
import HomePage from './interface/HomePage';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import EmployeerTab from './interface/EmployeerTab';
import AddEmployee from './interface/AddEmployee';
import EmployeeLogin from './interface/EmployeeLogin';
import JobHoursRecord from './interface/JobHoursRecord';
import EmployeerLog from './interface/EmployeerLog';

function App() {

  return (
    <Router>
      <Routes>
        <Route path="/" element={<HomePage/>} />
        <Route path="/employeedash" element={<EmployeeLogin/>} />
        <Route path="/employerlogin" element={<EmployeerLog/>} />
        <Route path="/jobhoursrecord" element={<JobHoursRecord/>} />
        <Route path="/employeertab" element={<EmployeerTab/>} />
        <Route path="/addemployee" element={<AddEmployee/>} />

      </Routes>
    </Router>
  );
}

export default App;
