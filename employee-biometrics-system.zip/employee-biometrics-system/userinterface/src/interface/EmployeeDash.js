import React from 'react'

const EmployeeDash = () => {
  return (
    <div>EmployeeDash</div>
  )
}

export default EmployeeDash