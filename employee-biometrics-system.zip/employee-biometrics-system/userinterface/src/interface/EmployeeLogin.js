import React, { useState } from 'react';
import { isEmployeeExist } from '../simulatorUI';

const EmployeeLogin = () => {
  const [userAddress, setUserAddress] = useState('');

  const handleUserAddressChange = (e) => {
    setUserAddress(e.target.value);
  };

  const employeeSign = async () => {
    const result = await isEmployeeExist(userAddress);
    if (result) {
      localStorage.setItem('employeeAddress', userAddress);
      console.log(result);
      window.location.href = '/jobhoursrecord'; 
    } else {
      alert('Invalid user address. Please try again.');
    }
  }

  return (
    <div className='container'>
      <div className='container-flex'>
        <div className="form-container">
          <p className="title1">Employee Login</p>
          <div className="form1">
            <div className="input-group1">
              <label htmlFor="useraddress">User Address</label>
              <input
                type="text"
                name="password"
                id="password"
                placeholder=""
                value={userAddress}
                onChange={handleUserAddressChange}
              />
            </div>
            <button type="button" className="sign1" onClick={employeeSign}>Sign in</button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default EmployeeLogin;
