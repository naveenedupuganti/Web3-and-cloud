import React, { useState } from 'react';
import { addEmployee } from '../simulatorUI';
import { isOrganizationExist } from '../simulatorUI';

const AddEmployee = () => {
  const [employeeName, setEmployeeName] = useState('');
  const [department, setDepartment] = useState('');
  const [wagePerHour, setWagePerHour] = useState();
  const [employeeAddress, setEmployeeAddress] = useState('');

  const handleAddEmpolyee = async () => {
    try {
      const result = await isOrganizationExist(localStorage.getItem('organizationAddress'));
      if (result) {
        addEmployee(localStorage.getItem('organizationAddress'), employeeAddress, employeeName, department, wagePerHour);
        alert('Employee Added Seuccessfully.')
      }
    } catch (error) {
      console.log(error)
    }
  }

  const handleEmployeeNameChange = (e) => {
    setEmployeeName(e.target.value);
  };

  const handleDepartmentChange = (e) => {
    setDepartment(e.target.value);
  };



  const handleWagePerHourChange = (e) => {
    setWagePerHour(e.target.value);
  };

  const handleEmployeeAddressChange = (e) => {
    setEmployeeAddress(e.target.value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Form submitted:', { employeeName, department, wagePerHour, employeeAddress });
  };

  return (
    <div className='container'>
      <div className='container-flex'>
        <div className="form1" onSubmit={handleSubmit}>
          <p className="title">Add Employee</p>
          <div className="flex">
            <label>
              <input
                className="input"
                type="text"
                placeholder="Employee Name"
                value={employeeName}
                onChange={handleEmployeeNameChange}
                required
              />
            </label>
            <label>
              <input
                className="input margin"
                type="text"
                placeholder="Department"
                value={department}
                onChange={handleDepartmentChange}
                required
              />
            </label>
          </div>

          <label>
            <input
              className="input"
              type="number"
              placeholder="Wage per hour"
              value={wagePerHour}
              onChange={handleWagePerHourChange}
              required
            />
          </label>
          <label>
            <input
              className="input"
              type="text"
              placeholder="Employee Address"
              value={employeeAddress}
              onChange={handleEmployeeAddressChange}
              required
            />
          </label>
          <button type="" className="submit" onClick={handleAddEmpolyee}>Submit</button>
        </div>
      </div>
    </div>

  );
}

export default AddEmployee;
