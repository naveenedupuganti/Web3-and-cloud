import React from 'react'
import { Link } from 'react-router-dom'
import './addbutton.css'
import { useState, useEffect } from 'react'
import { getEmployeesOfAnOrganization } from '../simulatorUI'
import { getAllEmployees } from '../simulatorUI'

const EmployeerTab = () => {

  const [employees, setEmployee] = useState([]);

  useEffect(() => {
    const fetchEmployees = async () => {
      try {
        const result = await getEmployeesOfAnOrganization(localStorage.getItem('organizationAddress'));
        setEmployee(result);
        console.log(result)
      } catch (error) {
        console.error('Error fetching Employees:', error);
      }
    };

    fetchEmployees();
  }, []);

  return (
    <>
      <div className='headerbar'>
        <h2>My Employees</h2>
        <Link to='/addemployee' className='link-button'><button type="button" className="button">
          <span className="button__text">Add Employee</span>
          <span className="button__icon"><svg xmlns="http://www.w3.org/2000/svg" width="24" viewBox="0 0 24 24" stroke-width="2" stroke-linejoin="round" stroke-linecap="round" stroke="currentColor" height="24" fill="none" className="svg"><line y2="19" y1="5" x2="12" x1="12"></line><line y2="12" y1="12" x2="19" x1="5"></line></svg></span>
        </button></Link>

      </div>
      <div className=' container-flex90vh'>
        <div className='container-grid container '>
        {employees.map(employee=>(<div className="cardfb ">
          <div className="card-inner">
            <div className="card-front grid">
              <p>Employee Name: <span className='text'>{employee.name}</span></p>
              <p>Department: <span className='text'>{employee.department}</span></p>
              <p>organization ID: <span className='text'>{employee.organizationId}</span></p>
            </div>

            <div className="card-back grid">
              <p>Employee Wage: <span className='text'>{employee.payPerHour} wei</span></p>
              <p>Total Hours Worked: <span className='text'>{employee.totalHoursWorked}</span></p>
              <p>Last ClockIn: <span className='text'>{employee.lastClockInTime}</span></p>
            </div>
          </div>
        </div>))
        }</div>
      


        
      </div></>
  )
}

export default EmployeerTab