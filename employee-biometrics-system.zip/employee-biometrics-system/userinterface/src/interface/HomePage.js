import React from 'react'
import { useState } from 'react'
import { Link } from 'react-router-dom'
import { addOrganization, isOrganizationExist } from '../simulatorUI'
const HomePage = () => {

    const [userAddress, setAddress] = useState('')
    const [organName, setName] = useState('')

    const handleUserAddress = (e) => {
        setAddress(e.target.value);

    }
    const handleOrganName = (e) => {
        setName(e.target.value);

    }
    const addHandler = async () => {

        const result= await isOrganizationExist(userAddress)
        if (!result) {
            
            addOrganization(userAddress, organName);
            alert('Added')
        }
        else{
            alert('Sorry!Organization on this Address Already Exists!')
        }
    
    }
    return (
        <>
            <div className='container '>
                <div className=' container-flex'>
                    <div className=" form">
                        <p className="form-title">Add New Organization</p>
                        <div className="input-container">
                            <input className='' type="text" value={userAddress} onChange={handleUserAddress} placeholder='Enter Organization Address' />

                        </div>
                        <div class="input-container">
                            <input className='' type="text" value={organName} onChange={handleOrganName} placeholder='Enter Organization Name' />
                        </div>
                            <button onClick={addHandler} className='submit'>Add</button>
                        
                        <div class="input-container">
                            <Link to='/employerlogin' className='none'>
                                <p>Login as Employeer?</p>
                            </Link>
                        </div>
                        <div class="input-container">
                            <Link to='/employeedash' className='none'>
                                <p>or login as Employee?</p>
                            </Link>
                        </div>
                    </div>
                </div>


            </div>
        </>
    )
}

export default HomePage