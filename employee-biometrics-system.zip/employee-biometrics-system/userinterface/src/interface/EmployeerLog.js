import React from 'react'
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { isOrganizationExist } from '../simulatorUI';
const EmployeerLog = () => {

    const [organizationAddress, setUserAddress] = useState('');
  
   
  
    const handleUserAddressChange = (e) => {
      setUserAddress(e.target.value);
    };
  
    const handleSubmit = (e) => {
      e.preventDefault();
      console.log('Form submitted:', {  organizationAddress });
    };

    const handleSignin=()=>{
        isOrganizationExist(organizationAddress);
        localStorage.setItem('organizationAddress',organizationAddress)
    }

  return (
<div className=' container'>
      <div className='   container-flex'>
        <div className=" form-container">
          <p className="title1">Employeer Login</p>
          <div className="form1" onSubmit={handleSubmit}>
           
            <div className="input-group1">
              <label htmlFor="useraddress">Organization Address</label>
              <input
                type="text"
                name="password"
                id="password"
                placeholder=""
                value={organizationAddress}
                onChange={handleUserAddressChange}
              />
            </div>
            <Link to='/employeertab'className='link-button'>  <button type="submit" className="sign1 " onClick={handleSignin}>Sign in</button>
            </Link>
          </div>
        </div>
      </div>
    </div>  )
}

export default EmployeerLog