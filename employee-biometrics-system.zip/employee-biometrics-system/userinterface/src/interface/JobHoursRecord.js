import React, { useEffect, useState } from 'react';
import { getAllClockRecordsOfAnEmployee, getEmployee } from '../simulatorUI';

const JobHoursRecord = () => {
  const [employeeData, setEmployeeData] = useState({});
  const [clockRecords, setClockRecords] = useState([]);

  useEffect(() => {
    const fetchEmployees = async () => {
      try {
        debugger;
        const employeeResult = await getEmployee(localStorage.getItem('employeeAddress'));
        const clockResult = await getAllClockRecordsOfAnEmployee(employeeResult.id);
        setEmployeeData(employeeResult);
        console.log(employeeResult)
        setClockRecords(clockResult);
      } catch (error) {
        console.error('Error fetching Employees:', error);
      }
    };

    fetchEmployees();
  }, []);

  return (
    <div className='container '>
      <div className="employee-header ">
        <h2>Hello {employeeData.name}</h2>
        <h2>ID: {employeeData.id}</h2>
        <h2>Department: {employeeData.department}</h2>
        <h2>Total Hours Worked: {employeeData.totalHoursWorked}</h2>
        <h2>Total Paid Hours: {employeeData.totalPaidHours}</h2>
      </div>

      <div className="clock-records">
        <h2>Clock Records</h2>
        <table>
          <thead>
            <tr>
              <th>Clock In</th>
              <th>Clock Out</th>
              <th>Date</th>
            </tr>
          </thead>
          <tbody>
            {clockRecords.map(record => (
              <tr key={record.id}>
                <td>{record.clockIn}</td>
                <td>{record.clockOut}</td>
                <td>{record.date}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default JobHoursRecord;
